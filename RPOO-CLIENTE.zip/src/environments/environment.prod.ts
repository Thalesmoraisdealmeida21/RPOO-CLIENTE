export const environment = {
  production: true,
  api: "https://api-rpg-1.herokuapp.com"
};

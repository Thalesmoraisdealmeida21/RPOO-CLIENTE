import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-challenger',
  templateUrl: './challenger.component.html',
  styleUrls: ['./challenger.component.scss']
})
export class ChallengerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

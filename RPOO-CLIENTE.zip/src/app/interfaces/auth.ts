export interface Auth {

    token: {
        token: string
    };
    username: string;
    id: number;
    status: string
}

export interface Group {

    name: string;
    description: string;
}

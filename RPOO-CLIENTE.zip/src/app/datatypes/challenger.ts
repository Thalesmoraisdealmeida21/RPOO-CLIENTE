export interface Challenger {
    name: String;
    level: String;
    group: String;
    user: String;
    userAdmin: String;
    difficulty: String
}

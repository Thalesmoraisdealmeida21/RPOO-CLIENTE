export interface User {

    id: number;
    username: string;
    password: string;
    email: string;
    bio: string;
    level: string;
    experience: string


}

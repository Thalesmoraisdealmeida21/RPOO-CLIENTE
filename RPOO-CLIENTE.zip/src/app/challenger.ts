export interface Challenger {
}
